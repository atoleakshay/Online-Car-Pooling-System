package com.myproject.contrllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.myproject.models.City;
import com.myproject.models.State;
import com.myproject.service.CityService;


@RestController
@CrossOrigin(origins = "http://localhost:8080")
public class CityController 
{
	@Autowired
	CityService cservice;
	@GetMapping("/getCities")
	public List<City> getAllCities()
	{
		return cservice.getAllcities();
	}
	
	@GetMapping("/getcity")
	public City getOneCity(@RequestParam("cityid") int cityid)
	{
		return cservice.getCity(cityid);
	}
	
	@GetMapping("/getOneCity/{cid}")
	public City getOne(@PathVariable("cid")int cityid)
	{
		return cservice.getCity(cityid);
	}
	
	@GetMapping("/getcitiesfromstate")
	public List<City> getCities(@RequestParam("sid")State stateid)
	{
		return cservice.getCities(stateid);
	}
	
	
	
}
