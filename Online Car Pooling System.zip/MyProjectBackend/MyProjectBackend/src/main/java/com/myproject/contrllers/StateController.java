package com.myproject.contrllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.myproject.models.State;
import com.myproject.service.StateService;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
public class StateController 
{
	@Autowired
	StateService sservice;
	
	@GetMapping("/getStates")
	public List<State> getAllStates()
	{
		return sservice.getStates();
	}
	
	@GetMapping("/getstate")
	public State getOneState(@RequestParam("stateid") int stateid)
	{
		return sservice.getState(stateid);
	}
	
	@GetMapping("/getOneState/{sid}")
	public State getOne(@PathVariable("sid")int stateid)
	{
		return sservice.getState(stateid);
	}
}
