package com.myproject.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myproject.models.Passenger;
import com.myproject.repository.PassengerRepository;


@Service
public class PassengerService {
	
	@Autowired
	PassengerRepository prepo;
	
	
	public Passenger savePassenger(Passenger passenger)
	{
		return prepo.save(passenger);
	}

	public List<Passenger> getPassenger()
	{
		return prepo.findAll();
	}
	
}
