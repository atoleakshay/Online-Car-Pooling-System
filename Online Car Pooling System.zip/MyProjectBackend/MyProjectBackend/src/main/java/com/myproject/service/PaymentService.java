package com.myproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myproject.models.Payment;
import com.myproject.repository.PaymentRepository;

@Service
public class PaymentService 
{
	@Autowired
	PaymentRepository prepo;
	
	public Payment save(Payment p)
	{
		return prepo.save(p);
	}
}
