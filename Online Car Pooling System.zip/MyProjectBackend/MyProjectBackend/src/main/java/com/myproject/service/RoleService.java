package com.myproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myproject.models.Role;
import com.myproject.repository.RoleRepository;
@Service
public class RoleService 
{
	@Autowired
	RoleRepository rrepo;
	
	
	public Role getRole(int id)
	{
		return rrepo.findById(id).get();
	}
	
}
