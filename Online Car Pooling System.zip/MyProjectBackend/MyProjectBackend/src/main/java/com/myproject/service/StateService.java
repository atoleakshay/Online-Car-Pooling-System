package com.myproject.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myproject.models.State;
import com.myproject.repository.StateRepository;

@Service
public class StateService 
{
	@Autowired
	StateRepository srepo;
	
	public List<State> getStates()
	{
		return srepo.findAll();
	}
	
	public State getState(int stateid)
	{
		Optional<State> ostate=srepo.findById(stateid);
		State s=null;
		try
		{
			s=ostate.get();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return s;
	}
}
