package com.myproject.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myproject.models.Login;
import com.myproject.models.User;
import com.myproject.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository urepo;
	
	public User getUser(Login l)
	{
		return urepo.getUser(l);
	}
	
	public User saveUser(User u)
	{
		return urepo.save(u);
	}
	
	public List<User> getUsers()
	{
		return urepo.findAll();
	}
	
	public User getUserId(int id)
	{
		return urepo.findById(id).get();
	}
}
