package com.example.MyProjectBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyProjectBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
